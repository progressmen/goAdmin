package constant

const (
	PrefixKey = "__prefix"
)
